#!/bin/bash

killall -9 node || true

